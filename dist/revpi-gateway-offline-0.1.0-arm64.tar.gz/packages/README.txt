Dieses Verzeichnis enthält .deb Pakete für Offline-Installationen.
Installiert werden sie via:
  sudo ./install.sh --offline

Hinweis:
- Falls dpkg fehlende Dependencies meldet, behebt install.sh das via:
  apt-get --no-download -f install
